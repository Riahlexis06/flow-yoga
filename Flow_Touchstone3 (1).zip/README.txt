Willow & Flow Yoga — Touchstone 3 starter project

Files:
- index.html: one-page website
- styles.css: external CSS, visual design system, Flexbox, and responsive media queries
- script.js: mobile navigation and demo form feedback

How to preview:
1. Keep all three files in the same folder.
2. Open index.html in a web browser.
3. Test the menu and contact form at desktop and mobile widths.

Before submitting:
- This project was recreated because the original Touchstone 2 website files were not available. Compare it with your Touchstone 2 work and make any changes your instructor requires.
- The schedule is sample content.
- The form is a demo and does not send email.
- Publish the folder using a public GitHub repository and GitHub Pages (or another permitted static host) to create the required repository and preview links. Those links cannot be filled in until you publish it.
